---
name: Discussion
about: Just type your opinions.
title: ''
labels: ''
assignees: ''

---

**Type your opinions or ideas here.**