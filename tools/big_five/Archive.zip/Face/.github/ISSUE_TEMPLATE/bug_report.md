---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

Before proposing this issue, plz search the existed issues by your keywords first.

**Describe the bug**

**To Reproduce**

**Expected behavior**

**Screenshots**

**Platform:**
 - macOS, Linux, or Windows

**Additional context**
Add any other context about the problem here.
